﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;  // Add this domainName
using System.Data.OleDb;  // Add this domainName OR sqlClient for sqlServer DB
using System.Data.SqlClient; // needed to make sqlConnection

/// <summary>
/// Summary description for myAdoHelper
/// ///  פעולות עזר לשימוש במסד נתונים מסוג אקסס או מסוג SQLSERVER
///  App_Data המסד ממוקם בתקיה 
/// </summary>
/// 
public class myAdoHelper
{
	public myAdoHelper()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static OleDbConnection ConnectToDB(string fileName)
    {
        // this method makes a connection to an Access DB thus it use the OleDb class
        string path = HttpContext.Current.Server.MapPath("App_Data/");  // the place of the DB within the Project
        path += fileName;
        // string path = HttpContext.Current.Server.MapPath("App_Data/" + fileName); //מאתר את מיקום מסד הנתונים מהשורש ועד התקייה בה ממוקם המסד

        string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data source=" + path;  //נתוני ההתחברות הכוללים מיקום וסוג המסד
        // string connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data source=" + path;  // for MS Access 2007 !!

        OleDbConnection conn = new OleDbConnection(connString); // declaring the object conn establishing connection 
        return conn;    // return the conn object. this conn object will be used in the next methods
    }

    public static SqlConnection ConnectToSqlDB(string fileName)
    {
        // this method makes a connection to an sqlServer DB thus it use the SqlConnection class
        string path = HttpContext.Current.Server.MapPath("App_Data/");  // the place of the DB within the Project
        path += fileName;
        // @ means take the string as it is without interprating signs like \
        string connString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=" + path + ";Integrated Security=True;User Instance=True";
        SqlConnection conn = new SqlConnection(connString);
        return conn;
    }
    // ................................................................................ // 

    /// <summary>
    /// To Execute update / insert / delete queries
    ///  הפעולה מקבלת שם קובץ ומשפט לביצוע ומבצעת את הפעולה על המסד
    /// </summary>

    public static void RunQuery(string fileName, string sql)  // runs a query at an Access DB
        // הפעולה מקבלת שם מסד נתונים ומחרוזת מחיקה/ הוספה/ עדכון ומבצעת את הפקודה על המסד הפיזי  
    {
        OleDbConnection conn = ConnectToDB(fileName);
        conn.Open();
        OleDbCommand com = new OleDbCommand(sql, conn);
        com.ExecuteNonQuery();
        //com.Dispose();  // releases all resources used by the connection
        conn.Close();
    }

    public static void RunQueryAtSqlS(string fileName, string sql)  // runs a query at an SqlServer
    // הפעולה מקבלת שם מסד נתונים ומחרוזת מחיקה/ הוספה/ עדכון ומבצעת את הפקודה על המסד הפיזי  
    {
        SqlConnection conn = ConnectToSqlDB(fileName);
        conn.Open();
        SqlCommand com = new SqlCommand(sql, conn);
        com.ExecuteNonQuery();
        com.Dispose();  // releases all resources used by the connection
        conn.Close();
    }

    // ................................................................................ // 

    /// <summary>
    /// To Execute update / insert / delete queries
    ///  הפעולה מקבלת שם קובץ ומשפט לביצוע ומחזירה את מספר השורות שהושפעו מביצוע הפעולה
    /// </summary>

    public int RowsAffected(string fileName, string sql)                  // Access version
    //  הפעולה מקבלת מסלול מסד נתונים ופקודת עדכון ומבצעת את הפקודה על המסד הפיזי  
    {
        OleDbConnection conn = ConnectToDB(fileName);                
        conn.Open();
        OleDbCommand com = new OleDbCommand(sql, conn);
        int rowsA = com.ExecuteNonQuery();  // executed the sql statment against the DB and returens the number of affected rows
        conn.Close();
        return rowsA;
    }

    public int RowsAffectedSqlS(string fileName, string sql)     // // SqlServer version
    {
        SqlConnection conn = ConnectToSqlDB(fileName);
        conn.Open();
        SqlCommand com = new SqlCommand(sql, conn);
        int rowsA = com.ExecuteNonQuery();
        conn.Close();
        return rowsA;
    }

    // ................................................................................ // 

    /// <summary>
    /// הפעולה מקבלת שם קובץ ומשפט לחיפוש ערך - מחזירה אמת אם הערך נמצא ושקר אחרת
    /// </summary>
    public static bool IsExist(string fileName, string sql)             // OleDb Version
    //הפעולה מקבלת שם קובץ ומשפט בחירת נתון ומחזירה אמת אם הנתונים קיימים ושקר אחרת
    {
        OleDbConnection conn = ConnectToDB(fileName);
        conn.Open();
        OleDbCommand com = new OleDbCommand(sql, conn);
        OleDbDataReader data = com.ExecuteReader();  // the method ExecuteReader retrievs data after executing the query
        bool found;
        found = (bool)data.Read();  // אם יש נתונים לקריאה יושם אמת אחרת שקר - הערך קיים במסד הנתונים
        conn.Close();
        return found;
    }

    public static bool IsExistSqlS(string fileName, string sql)             // Sql version
    //הפעולה מקבלת שם קובץ ומשפט בחירת נתון ומחזירה אמת אם הנתונים קיימים ושקר אחרת
    {
        SqlConnection conn = ConnectToSqlDB(fileName);
        conn.Open();
        SqlCommand com = new SqlCommand(sql, conn);
        SqlDataReader data = com.ExecuteReader();  // the method ExecuteReader retrievs data after executing the query
        bool found;
        found = (bool)data.Read();  // אם יש נתונים לקריאה יושם אמת אחרת שקר - הערך קיים במסד הנתונים
        conn.Close();
        return found;
    }

    // ................................................................................ // 

    // creates a DataTable object which contains a copy of retrieved data after running the sql query
    public static DataTable ExecuteDataTable(string fileName, string sql)
    {
        OleDbConnection conn = ConnectToDB(fileName);
        conn.Open();
        OleDbDataAdapter tableAdapter = new OleDbDataAdapter(sql, conn); // enables the access to the DB
        DataTable dt = new DataTable(); 
        tableAdapter.Fill(dt);   // fill with retrieved data
        return dt;
    }

    public static DataTable ExecuteDataTableSqlS(string fileName, string sql)
    {
        SqlConnection conn = ConnectToSqlDB(fileName);
        conn.Open();
        SqlDataAdapter tableAdapter = new SqlDataAdapter(sql, conn); // enables the access to the DB
        DataTable dt = new DataTable();
        tableAdapter.Fill(dt);   // fill with retrieved data
        return dt;
    }


    // following method builds a table to be shown with the content of the DataTable 
    public static string printDataTable(string fileName, string sql)//הפעולה מקבלת שם קובץ ומשפט בחירת נתון ומחזירה אמת אם הנתונים קיימים ושקר אחרת
    {
        DataTable dt = ExecuteDataTable(fileName, sql);
        string printStr = "<table border='1' width='30%'>";
        foreach (DataRow row in dt.Rows)
        {
            printStr += "<tr>";
            foreach (object myItemArray in row.ItemArray)
            {
                printStr += "<td>" + myItemArray.ToString() + "</td>";
            }
            printStr += "</tr>";
        }
        printStr += "</table>";
        return printStr;
    }

    // same as previous for sqlServer
    //public static string printDataTable(string fileName, string sql)//הפעולה מקבלת שם קובץ ומשפט בחירת נתון ומחזירה אמת אם הנתונים קיימים ושקר אחרת
    //{
    //    DataTable dt = ExecuteDataTableSqlS(fileName, sql);
    //    string printStr = "<table border='1'>";
    //    foreach (DataRow row in dt.Rows)
    //    {
    //        printStr += "<tr>";
    //        foreach (object myItemArray in row.ItemArray)
    //        {
    //            printStr += "<td>" + myItemArray.ToString() + "</td>";
    //        }
    //        printStr += "</tr>";
    //    }
    //    printStr += "</table>";
    //    return printStr;
    //}

}